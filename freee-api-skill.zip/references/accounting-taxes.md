# Taxes

## 概要

税区分

## エンドポイント一覧

### GET /api/1/taxes/codes

操作: 税区分一覧の取得（廃止予定）

説明: 概要 税区分一覧を取得する 注意点 このAPIは廃止予定のため非推奨です。api/1/taxes/companies/{company_id}（指定した事業所の税区分一覧の取得）をご利用ください。

### レスポンス (200)

- taxes (必須): array[object]
  配列の要素:
    - code (必須): integer(int64) - 税区分コード 例: `21` (最小: 1, 最大: 2147483647)
    - name (必須): string - 税区分名 例: `sales_with_tax`
    - name_ja (必須): string - 税区分名（日本語表示用） 例: `課税売上`

### GET /api/1/taxes/codes/{code}

操作: 税区分の取得

説明: 概要 税区分を取得する

### パラメータ

| 名前 | 位置 | 必須 | 型 | 説明 |
|------|------|------|-----|------|
| code | path | はい | integer(int64) | 税区分コード |

### レスポンス (200)

- tax (必須): object
  - code (必須): integer(int64) - 税区分コード 例: `21` (最小: 1, 最大: 2147483647)
  - name (必須): string - 税区分名 例: `sales_with_tax`
  - name_ja (必須): string - 税区分名（日本語表示用） 例: `課税売上`

### GET /api/1/taxes/companies/{company_id}

操作: 指定した事業所の税区分一覧の取得

説明: 概要 指定した事業所の税区分一覧を取得する

### パラメータ

| 名前 | 位置 | 必須 | 型 | 説明 |
|------|------|------|-----|------|
| company_id | path | はい | integer(int64) | 事業所ID |
| display_category | query | いいえ | string | 税区分の表示カテゴリ（ tax_5: 5%表示の税区分、 tax_8: 8%表示の税区分、 tax_r8: 軽減税率8%表示の税区分、 tax_10: 10%表示の税区分、 tax_5_e80: インボイス経過措置5%表示80%控除の税区分、 tax_5_e50: インボイス経過措置5%表示50%控除の税区分、 tax_8_e80: インボイス経過措置8%表示80%控除の税区分、 tax_8_e50: インボイス経過措置8%表示50%控除の税区分、 tax_r8_e80: インボイス経過措置軽減税率8%表示80%控除の税区分、 tax_r8_e50: インボイス経過措置軽減税率8%表示50%控除の税区分、 tax_10_e80: インボイス経過措置10%表示80%控除の税区分、 tax_10_e50: インボイス経過措置10%表示50%控除の税区分） (選択肢: tax_5, tax_8, tax_r8, tax_10, tax_5_e80, tax_5_e50, tax_8_e80, tax_8_e50, tax_r8_e80, tax_r8_e50, tax_10_e80, tax_10_e50) |
| available | query | いいえ | boolean | 税区分の使用設定。true: 使用する、false: 使用しない |

### レスポンス (200)

- taxes (必須): array[object]
  配列の要素:
    - code (必須): integer(int64) - 税区分コード 例: `21` (最小: 0, 最大: 2147483647)
    - name (必須): string - 税区分名 例: `sales_with_tax`
    - name_ja (必須): string - 税区分名（日本語表示用） 例: `課税売上`
    - display_category (必須): string - 税区分の表示カテゴリ（ tax_5: 5%表示の税区分、 tax_8: 8%表示の税区分、 tax_r8: 軽減税率8%表示の税区分、 tax_10: 10%表示の税区分、 tax_5_e80: インボイス経過措置5%表示80%控除の税区分、 tax_5_e50: インボイス経過措置5%表示50%控除の税区分、 tax_8_e80: インボイス経過措置8%表示80%控除の税区分、 tax_8_e50: インボイス経過措置8%表示50%控除の税区分、 tax_r8_e80: インボイス経過措置軽減税率8%表示80%控除の税区分、 tax_r8_e50: インボイス経過措置軽減税率8%表示50%控除の税区分、 tax_10_e80: インボイス経過措置10%表示80%控除の税区分、 tax_10_e50: インボイス経過措置10%表示50%控除の税区分、 null: 税率未設定税区分） (選択肢: tax_5, tax_8, tax_r8, tax_10, tax_5_e80, tax_5_e50, tax_8_e80, tax_8_e50, tax_r8_e80, tax_r8_e50, tax_10_e80, tax_10_e50) 例: `tax_8`
    - available (必須): boolean - 税区分の使用設定。true: 使用する、false: 使用しない 例: `true`



## 参考情報

- freee API公式ドキュメント: https://developer.freee.co.jp/docs
- OpenAPIスキーマ: [accounting-api-schema.json](../../openapi/accounting-api-schema.json)
